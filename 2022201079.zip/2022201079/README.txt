For q1.sh
	1. when there are odd number of lines the program is taking the floor value for middle value.
